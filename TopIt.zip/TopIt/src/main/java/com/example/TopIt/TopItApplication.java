package com.example.TopIt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TopItApplication {

	public static void main(String[] args) {
		SpringApplication.run(TopItApplication.class, args);
	}

}
