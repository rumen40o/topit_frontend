import {Route, Routes} from 'react-router-dom';
import Home from "./pages/Home";
import Events from "./pages/Events";
import Employees from "./pages/Employees";
import Tasks from "./pages/Tasks";
import Account from "./pages/Account";
import './App.css';
import NavBar from './navbar/NavBar';




function App() {
  
  return (
    <>
      <Routes>
         <Route path='/' element={<Home/>}/>
         <Route path='/employee' element={<Employees/>}/>
         <Route path='/task' element={<Tasks/>}/>
         <Route path='/event' element={<Events/>}/>
         <Route path='/account' element={<Account/>}/>
      </Routes>
      <NavBar/>
    </>
  );
}

export default App;
