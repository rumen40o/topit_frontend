const Event = () => {
  return <h1>Events</h1>;
};

export default Event;