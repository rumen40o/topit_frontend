const Tasks = () => {
    return <h1>Tasks</h1>;
  };
  
  export default Tasks;