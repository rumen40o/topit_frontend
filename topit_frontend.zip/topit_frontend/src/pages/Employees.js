const Employees = () => {
    return <h1>Employees</h1>;
  };
  
  export default Employees;