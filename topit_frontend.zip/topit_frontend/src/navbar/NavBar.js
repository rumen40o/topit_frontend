import { Link } from "react-router-dom";
import './navbar.css';


export default function NavBar(){
const buttonHightlight = document.getElementById('buttonHighlight');
let selected;
function moveHightlight(targetId) {
        const button = document.getElementById(`button-${targetId}`);
        if(button === selected)
            return;
        button.classList.add('selected');
        if(selected != null)
            selected.classList.remove('selected');
        selected = button;
    
        buttonHightlight.classList = `highlight on-${targetId}`;
        window.location.reload()
        
    }
    return(

        <div id="container">
        <div class="highlight" id="buttonHighlight">
            <div class="highlight mid"></div>
            <div class="highlight top"></div>
            <div class="highlight bot"></div>
        </div>
        
            <Link to="/"><button class="button one selected" id="button-1" onClick={moveHightlight(1)}>Home</button></Link>
            <Link to="/employee"><button class="button two" id="button-2" onClick={moveHightlight(2)}>Employees</button></Link>
            <Link to="/task"><button class="button three" id="button-3" onClick={moveHightlight(3)}>Tasks</button></Link>
            <Link to="/event"><button class="button four" id="button-4" onClick={moveHightlight(4)}>Events</button></Link>
            <div id="spacerDiv"></div>
            <Link to="/account"><button class="button five" id="button-5" onclick={moveHightlight(5)}>Account</button></Link> 
    </div>
    );
}